import gurobipy as gp  # pylint: disable=no-name-in-module
import numpy as np
import torch

class proGrbSolver(optGrbSolver):
    def __init__(self, num_stocks, modelSense=None, alpha=1, **kwargs):
        super().__init__(modelSense)
        print("alpha: ", alpha)
        self.num_stocks = num_stocks
        self.solver = self._create_cvxpy_problem(alpha)
    
    def num_vars(self):
        return self.num_stocks
    


    def solve(self, Y, sqrt_covar):
        return self.solver(Y, sqrt_covar)